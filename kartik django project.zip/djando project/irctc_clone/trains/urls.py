from django.urls import path
from . import views

urlpatterns = [
    path('check/', views.check_form, name='check_availability'),  # Form page
    path('search/', views.train_search, name='search_trains'),    # Search result
]
