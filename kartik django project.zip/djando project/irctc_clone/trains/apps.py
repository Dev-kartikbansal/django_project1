from django.apps import AppConfig

class TrainsConfig(AppConfig):
    name = 'trains'
