from django.db import models

class Train(models.Model):
    train_name = models.CharField(max_length=100, default='Express')
    source = models.CharField(max_length=100, default='Delhi')
    destination = models.CharField(max_length=100, default='Mumbai')
    departure_time = models.TimeField(default='01:01:01')
    arrival_time = models.TimeField(default='00:00:00')
    price = models.DecimalField(max_digits=8, decimal_places=2, default=100.00)
    available_seats = models.IntegerField(default=50)

    def __str__(self):
        return f"{self.train_name} - {self.source} to {self.destination}"
