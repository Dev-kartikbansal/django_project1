from django.shortcuts import render
from .models import Train

def check_form(request):
    return render(request, 'check_availability.html')

def train_search(request):
    trains = []
    if request.method == 'GET':
        source = request.GET.get('source')
        destination = request.GET.get('destination')
        trains = Train.objects.filter(source__icontains=source, destination__icontains=destination)
    return render(request, 'search_trains.html', {'trains': trains})
